using System.IO;

namespace SwinAdventure
{
    public abstract class GameObject : IdentifiableObject
    {
        private string _name;
        private string _description;

        public GameObject(string[] idents, string name, string desc) : base(idents)
        {
            _name = name;
            _description = desc;
        }

        public string Name => _name;
        public string ShortDescription => $"a {_name} ({FirstId})";
        public virtual string FullDescription => _description;

        public virtual void SaveTo(StreamWriter writer)
        {
            writer.WriteLine(Name);
            writer.WriteLine(FullDescription);
        }

        public virtual void LoadFrom(StreamReader reader)
        {
            _name = reader.ReadLine();
            _description = reader.ReadLine();
        }
    }
}

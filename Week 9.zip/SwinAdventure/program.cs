using System;
using System.IO;
using System.Collections.Generic;
using SwinAdventure;

class Program
{
    static void Main(string[] args)
    {
        
        Player testPlayer = new Player("Vasudev", "The brave adventurer");
        Item hat = new Item(new string[] { "silver" }, "Silver Hat", "A shiny silver hat");
        Item torch = new Item(new string[] { "light" }, "Torch", "A wooden torch");
        testPlayer.Inventory.Put(hat);
        testPlayer.Inventory.Put(torch);

       
        Bag backpack = new Bag(new string[] { "backpack" }, "Leather Backpack", "A durable leather backpack");
        Item map = new Item(new string[] { "map" }, "Treasure Map", "An old treasure map");
        Item rope = new Item(new string[] { "rope" }, "Climbing Rope", "A sturdy climbing rope");
        backpack.Inventory.Put(map);
        backpack.Inventory.Put(rope);

       
        testPlayer.Inventory.Put(backpack);

       
        using (StreamWriter writer = new StreamWriter("TestPlayer.txt"))
        {
            testPlayer.SaveTo(writer);
        }

       
        using (StreamReader reader = new StreamReader("TestPlayer.txt"))
        {
            testPlayer.LoadFrom(reader);
        }

        Console.WriteLine("\n--- Polymorphism Test ---");

       
        List<IHaveInventory> containers = new List<IHaveInventory>();
        containers.Add(testPlayer);
        containers.Add(backpack);

       
        foreach (IHaveInventory container in containers)
        {
            Console.WriteLine($"Container: {container.Name}");
            Console.WriteLine($"Located 'map': {container.Locate("map")}");
            Console.WriteLine($"Located 'silver': {container.Locate("silver")}");
            Console.WriteLine($"Located 'rope': {container.Locate("rope")}");
            Console.WriteLine();
        }
    }
}

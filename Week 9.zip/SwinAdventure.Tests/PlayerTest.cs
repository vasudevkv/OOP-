using NUnit.Framework;
using SwinAdventure;

namespace SwinAdventure.Tests
{
    [TestFixture]
    public class PlayerTests
    {
        private Player _player;
        private Item _sword;

        [SetUp]
        public void Setup()
        {
            _player = new Player("Fred", "The mighty programmer");
            _sword = new Item(new string[] { "sword" }, "bronze sword", "A shiny medieval weapon");
            _player.Inventory.Put(_sword);
        }

        [Test]
        public void TestPlayerIsIdentifiable()
        {
            Assert.IsTrue(_player.AreYou("me"));
            Assert.IsTrue(_player.AreYou("inventory"));
        }

        [Test]
        public void TestPlayerLocatesItems()
        {
            Assert.AreEqual(_sword, _player.Locate("sword"));
        }

        [Test]
        public void TestPlayerLocatesItself()
        {
            Assert.AreEqual(_player, _player.Locate("me"));
        }

        [Test]
        public void TestPlayerLocatesNothing()
        {
            Assert.IsNull(_player.Locate("hammer"));
        }

        [Test]
        public void TestPlayerFullDescription()
        {
            string desc = _player.FullDescription;
            Assert.IsTrue(desc.Contains("You are Fred"));
            Assert.IsTrue(desc.Contains("The mighty programmer"));
            Assert.IsTrue(desc.Contains("a bronze sword (sword)"));
        }
    }
}

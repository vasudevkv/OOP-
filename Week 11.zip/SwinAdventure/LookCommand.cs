using System;

namespace SwinAdventure
{
    public class LookCommand : Command
    {
        public LookCommand(string[] verbs) : base(verbs) { }

        public override string Execute(Player p, string[] text)
        {
           
            if (text.Length == 1 && text[0].Equals("look", StringComparison.InvariantCultureIgnoreCase))
                return p.Location.FullDescription;

           
            if (text.Length == 3 && text[0].Equals("look", StringComparison.InvariantCultureIgnoreCase)
                && text[1].Equals("at", StringComparison.InvariantCultureIgnoreCase))
            {
                var id = text[2].ToLower();
                var obj = p.Locate(id);
                if (obj != null)
                    return obj.FullDescription;
                return $"I cannot find the {id}";
            }

           
            if (text.Length == 5 && text[0].Equals("look", StringComparison.InvariantCultureIgnoreCase)
                && text[1].Equals("at", StringComparison.InvariantCultureIgnoreCase)
                && text[3].Equals("in", StringComparison.InvariantCultureIgnoreCase))
            {
                var thingId = text[2].ToLower();
                var containerId = text[4].ToLower();
                var containerObj = p.Locate(containerId);
                if (containerObj is IHaveInventory container)
                {
                    var obj = container.Locate(thingId);
                    if (obj != null)
                        return obj.FullDescription;
                    return $"I cannot find the {thingId} in the {container.Name}";
                }
                return $"I cannot find the {containerId}";
            }

            return "I don't know how to look like that";
        }
    }
}

using System;
using SwinAdventure;

using GamePath = SwinAdventure.Path;

class Program
{
    static void Main(string[] args)
    {
        var outsideIds = new[] { "outside" };
        var hallwayIds = new[] { "hallway" };
        var courtyardIds = new[] { "courtyard" };
        var insideIds = new[] { "inside" };
;
        var outside = new Location(outsideIds, "Outside", "You are standing outside the castle.");
        outside.Inventory.Put(new Item(new[] { "key" }, "Golden Key", "A shiny golden key is lying in the grass."));

        var hallway = new Location(hallwayIds, "Hallway", "You are in a grand hallway with portraits on the walls.");
        hallway.Inventory.Put(new Item(new[] { "painting" }, "Painting", "A spooky painting"));

        var courtyard = new Location(courtyardIds, "Courtyard", "You are in a beautiful courtyard filled with flowers.");
        courtyard.Inventory.Put(new Item(new[] { "statue" }, "Marble Statue", "A tall marble statue stands here."));

        var inside = new Location(insideIds, "outside", "You are in a beautiful courtyard filled with flowers.");
        courtyard.Inventory.Put(new Item(new[] { "statue" }, "Marble Statue", "A tall marble statue stands here."));



        

      
        outside.AddPath(new GamePath(new[] { "north" }, hallway));
        hallway.AddPath(new GamePath(new[] { "south" }, outside));

        hallway.AddPath(new GamePath(new[] { "east" }, courtyard));
        courtyard.AddPath(new GamePath(new[] { "west" }, hallway));
        outside.AddPath(new GamePath(new[] { "east-south" }, outside));



        Console.Write("Enter player name: ");
        var name = Console.ReadLine() ?? "Adventurer";
        Console.Write("Enter player description: ");
        var desc = Console.ReadLine() ?? "The brave explorer.";
        var player = new Player(name, desc, outside);

        player.Inventory.Put(new Item(new[] { "silver" }, "Silver Hat", "A shiny silver hat"));
        player.Inventory.Put(new Item(new[] { "light" }, "Torch", "A wooden torch"));
        var bag = new Bag(new[] { "backpack" }, "Leather Backpack", "A durable leather backpack");
        bag.Inventory.Put(new Item(new[] { "map" }, "Treasure Map", "An old treasure map"));
        player.Inventory.Put(bag);

        var commands = new Command[] {
            new LookCommand(new[] { "look" }),
            new MoveCommand(new[] { "move", "go" })
        };

        Console.WriteLine("\nType commands like \"look at torch\" or \"look\" to examine location, or \"move north\" to travel.");
        Console.WriteLine("Type \"quit\" to exit.\n");

        while (true)
        {
            Console.Write("> ");
            var input = Console.ReadLine()?.Trim();
            if (string.IsNullOrEmpty(input) || input.Equals("quit", StringComparison.InvariantCultureIgnoreCase))
                break;

            var parts = input.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            string output = null;
            foreach (var cmd in commands)
            {
                if (cmd.AreYou(parts[0].ToLower()))
                {
                    output = cmd.Execute(player, parts);
                    break;
                }
            }
            Console.WriteLine((output ?? "I don't understand that.") + "\n");
        }
    }
}

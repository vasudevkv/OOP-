namespace SwinAdventure
{
    public class Path : IdentifiableObject
    {
        public Location Destination { get; }

        public string Direction => FirstId;

        public Path(string[] ids, Location destination) : base(ids)
        {
            Destination = destination;
        }
    }
}






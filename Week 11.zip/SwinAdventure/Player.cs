using System.IO;

namespace SwinAdventure
{
    public class Player : GameObject, IHaveInventory
    {
        private Inventory _inventory = new Inventory();
        public Location Location { get; set; }

        public Player(string name, string desc, Location startLocation)
            : base(new[] { "me", "inventory" }, name, desc)
        {
            Location = startLocation;
        }

        public Inventory Inventory => _inventory;

        public override string FullDescription =>
            $"You are {Name}, {base.FullDescription}\nYou are carrying:\n{_inventory.ItemList}";

        public GameObject? Locate(string id)
        {
            if (AreYou(id)) return this;
            var item = _inventory.Fetch(id);
            if (item != null) return item;
            return Location.Locate(id);
        }

        public override void SaveTo(StreamWriter writer)
        {
            base.SaveTo(writer);
            writer.WriteLine(_inventory.ItemList);
        }

        public override void LoadFrom(StreamReader reader)
        {
            base.LoadFrom(reader);
            var itemList = reader.ReadLine() ?? string.Empty;
            Console.WriteLine("Player data loaded: {0} carrying {1}", Name, itemList);
        }
    }
}
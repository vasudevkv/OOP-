namespace SwinAdventure
{
    public class MoveCommand : Command
    {
        public MoveCommand(string[] verbs) : base(verbs) { }

        public override string Execute(Player player, string[] text)
        {
            if (text.Length < 2)
                return "Where do you want to go?";

            var dir = text[1].ToLower();
            var path = player.Location.GetPath(dir);
            if (path == null)
                return "You can't go that way.";

            player.Location = path.Destination;
            return $"You move {dir}.\n{player.Location.FullDescription}";
        }
    }
}

using System;
using System.Collections.Generic;

namespace SwinAdventure
{
    public class Location : GameObject, IHaveInventory
    {
        private Inventory _inventory;
        private Dictionary<string, Path> _paths = new Dictionary<string, Path>(StringComparer.InvariantCultureIgnoreCase);

        public Location(string[] ids, string name, string desc) : base(ids, name, desc)
        {
            _inventory = new Inventory();
        }

        public Inventory Inventory
        {
            get { return _inventory; }
        }

       
        public GameObject Locate(string id)
        {
            if (AreYou(id))
                return this;

            GameObject item = _inventory.Fetch(id);
            if (item != null)
                return item;

        
            return null;
        }

        public override string FullDescription
        {
            get
            {
                string nameDescription = string.IsNullOrEmpty(Name) ? "an Unknown location" : Name;
                string inventoryDescription = (_inventory != null && _inventory.ItemList != "nothing.")
                    ? _inventory.ItemList
                    : "There are no items in this location.";

                return $"You are in {nameDescription}. {base.FullDescription}\nHere, you can see:\n{inventoryDescription}";
            }
        }

    
        public string ListPath()
        {
            if (_paths.Count == 0)
                return "There are no paths from here.";

            string result = "Possible path(s): ";
            foreach (var path in _paths.Values)
            {
                result += path.Direction + " ";
            }
            return result.Trim();
        }

        public void AddPath(Path path)
        {
            if (!_paths.ContainsKey(path.Direction))
            {
                _paths[path.Direction] = path;
            }
        }

        public Path GetPath(string id)
        {
            _paths.TryGetValue(id, out var path);
            return path;
        }
    }
}

using NUnit.Framework;

namespace SwinAdventure.Tests
{
    [TestFixture]
    public class BagTests
    {
        private Bag _bag;
        private Item _sword;
        private Item _shield;

        [SetUp]
        public void Setup()
        {
            _bag = new Bag(new string[] { "bag" }, "leather bag", "A small leather bag");
            _sword = new Item(new string[] { "sword" }, "silver sword", "A shiny silver sword");
            _shield = new Item(new string[] { "shield" }, "wooden shield", "A sturdy shield");
            _bag.Inventory.Put(_sword);
            _bag.Inventory.Put(_shield);
        }

        [Test]
        public void TestBagLocatesItself()
        {
            Assert.AreEqual(_bag, _bag.Locate("bag"));
        }

        [Test]
        public void TestBagLocatesItems()
        {
            Assert.AreEqual(_sword, _bag.Locate("sword"));
            Assert.AreEqual(_shield, _bag.Locate("shield"));
             Assert.AreEqual(_bag, _bag.Locate("bag"));
        }

        [Test]
        public void TestBagLocatesNothing()
        {
            Assert.IsNull(_bag.Locate("potion"));
        }

        [Test]
        public void TestBagFullDescription()
        {
            string desc = _bag.FullDescription;
            Assert.IsTrue(desc.Contains("In the leather bag you can see:"));
            Assert.IsTrue(desc.Contains(_sword.ShortDescription));
            Assert.IsTrue(desc.Contains(_sword.ShortDescription));
            Assert.IsTrue(desc.Contains(_shield.ShortDescription));
            Assert.IsTrue(desc.Contains(_shield.ShortDescription));

        }

        [Test]
        public void TestBagInBag()
        {
            Bag innerBag = new Bag(new string[] { "pouch" }, "small pouch", "A tiny pouch");
            Item coin = new Item(new string[] { "coin" }, "gold coin", "A shiny gold coin");
            innerBag.Inventory.Put(coin);
            _bag.Inventory.Put(innerBag);

            Assert.AreEqual(innerBag, _bag.Locate("pouch"));
            Assert.AreEqual(_sword, _bag.Locate("sword"));
            Assert.IsNull(_bag.Locate("coin"));
        }
    }
}

using NUnit.Framework;
using SwinAdventure;

namespace SwinAdventure.Tests
{
    [TestFixture]
    public class LookCommandTests
    {
        private Player _player;
        private LookCommand _command;

        [SetUp]
        public void Setup()
        {
            _player = new Player("Tester", "Test player");
            _command = new LookCommand(new[] { "look" });
        }

        [Test]
        public void TestLookInvalidInputLength()
        {
            var output = _command.Execute(_player, new[] { "look", "around", "quickly" });
            Assert.AreEqual("I don't know how to look like that", output);
        }

        [Test]
        public void TestLookAtInventory()
        {
            var output = _command.Execute(_player, new[] { "look", "at", "inventory" });
            Assert.AreEqual(_player.FullDescription, output);
        }

        [Test]
        public void TestLookAtItemInInventory()
        {
            var key = new Item(new[] { "key" }, "Key", "A small key");
            _player.Inventory.Put(key);
            var output = _command.Execute(_player, new[] { "look", "at", "key" });
            Assert.AreEqual(key.FullDescription, output);
        }

        [Test]
        public void TestLookAtNonexistentItemInPlayer()
        {
            var output = _command.Execute(_player, new[] { "look", "at", "gem" });
            Assert.AreEqual("I cannot find the gem in the Player", output);
        }

        [Test]
        public void TestLookAtItemInContainer()
        {
            var box = new Bag(new[] { "box" }, "Box", "A wooden box");
            _player.Inventory.Put(box);
            var coin = new Item(new[] { "coin" }, "Coin", "A shiny coin");
            box.Inventory.Put(coin);
            var output = _command.Execute(_player, new[] { "look", "at", "coin", "in", "box" });
            Assert.AreEqual(coin.FullDescription, output);
        }

        [Test]
        public void TestLookAtItemInNonexistentContainer()
        {
            var output = _command.Execute(_player, new[] { "look", "at", "coin", "in", "bag" });
            Assert.AreEqual("I cannot find the bag", output);
        }

        [Test]
        public void TestLookAtNonexistentItemInContainer()
        {
            var sack = new Bag(new[] { "sack" }, "Sack", "A cloth sack");
            _player.Inventory.Put(sack);
            var output = _command.Execute(_player, new[] { "look", "at", "gem", "in", "sack" });
            Assert.AreEqual("I cannot find the gem in the Sack", output);
        }

        [Test]
        public void TestInvalidSyntax()
        {
            Assert.AreEqual("Error in look input",
                _command.Execute(_player, new[] { "see", "at", "box" }));
            Assert.AreEqual("What do you want to look at?",
                _command.Execute(_player, new[] { "look", "around", "box" }));
            Assert.AreEqual("What do you want to look in?",
                _command.Execute(_player, new[] { "look", "at", "box", "inside", "box" }));
            
        }
    }
}

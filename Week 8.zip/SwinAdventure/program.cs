using System.IO;
using SwinAdventure;

class Program
{
    static void Main(string[] args)
    {
        Player testPlayer = new Player("Vasudev", "The brave adventurer");
        Item hat = new Item(new string[] { "silver" }, "Silver Hat", "A shiny silver hat");
        Item torch = new Item(new string[] { "light" }, "Torch", "A wooden torch");

        testPlayer.Inventory.Put(hat);
        testPlayer.Inventory.Put(torch);

        using (StreamWriter writer = new StreamWriter("TestPlayer.txt"))
        {
            testPlayer.SaveTo(writer);
        }

        using (StreamReader reader = new StreamReader("TestPlayer.txt"))
        {
            testPlayer.LoadFrom(reader);
        }
    }
}

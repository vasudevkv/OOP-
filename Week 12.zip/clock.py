import datetime
import time
import tracemalloc

class SimpleClock:
    def __init__(self, use12Hour=False):
        now = datetime.datetime.now()
        self.h = now.hour
        self.m = now.minute
        self.s = now.second
        self.use12Hour = use12Hour

        print(f"[Init] Time now: {self.formatTime(self.h, self.m, self.s)}")

    def tick(self):
        self.s += 1
        if self.s == 60:
            self.s = 0
            self.m += 1
        if self.m == 60:
            self.m = 0
            self.h += 1
        if (self.use12Hour and self.h == 12) or (not self.use12Hour and self.h == 24):
            self.h = 0

    def reset(self):
        self.h = self.m = self.s = 0

    def getTime(self):
        return self.formatTime(self.h, self.m, self.s)

    def formatTime(self, h, m, s):
        if self.use12Hour:
            suffix = 'AM' if h < 12 else 'PM'
            displayH = h % 12 or 12
            return f"{displayH:02}:{m:02}:{s:02} {suffix}"
        else:
            return f"{h:02}:{m:02}:{s:02}"


if __name__ == "__main__":
    studentIdLastDigit = 9
    clockFormat12h = studentIdLastDigit <= 5

    print("Using 12-hour format?", clockFormat12h)
    clock = SimpleClock(use12Hour=clockFormat12h)

    print("Start:", clock.getTime())

    tracemalloc.start()
    start = time.time()
    for _ in range(1000):
        clock.tick()
    end = time.time()
    current, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()

    print("After ticks:", clock.getTime())
    print("Time taken: {:.0f} ms".format((end - start) * 1000))
    print("Peak memory: {} bytes".format(peak))

    clock.reset()
    print("Reset:", clock.getTime())

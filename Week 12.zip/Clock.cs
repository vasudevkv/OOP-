using System;

namespace CounterTask
{
    public class Clock
    {
        private Counter _hours;
        private Counter _minutes;
        private Counter _seconds;
        private bool _is12HourFormat;

        public Clock(bool is12HourFormat)
        {
            _hours = new Counter("Hours");
            _minutes = new Counter("Minutes");
            _seconds = new Counter("Seconds");
            _is12HourFormat = is12HourFormat;

            DateTime now = DateTime.Now.ToLocalTime();
            Console.WriteLine("DEBUG: System Time is " + now.ToString("F")); 

            _hours.Set(now.Hour);
            _minutes.Set(now.Minute);
            _seconds.Set(now.Second);
        }

        public void Tick()
        {
            _seconds.Increment();
            if (_seconds.Ticks >= 60)
            {
                _seconds.Reset();
                _minutes.Increment();

                if (_minutes.Ticks >= 60)
                {
                    _minutes.Reset();
                    _hours.Increment();

                    if (_is12HourFormat && _hours.Ticks >= 12)
                    {
                        _hours.Set(0);
                    }
                    else if (!_is12HourFormat && _hours.Ticks >= 24)
                    {
                        _hours.Set(0);
                    }
                }
            }
        }

        public void Reset()
        {
            _hours.Set(0);
            _minutes.Set(0);
            _seconds.Set(0);
        }

        public string GetTime()
        {
            int hr = _hours.Ticks;
            string suffix = "";

            if (_is12HourFormat)
            {
                suffix = hr >= 12 ? "PM" : "AM";
                if (hr == 0) hr = 12;
                else if (hr > 12) hr -= 12;
                return $"{hr:D2}:{_minutes.Ticks:D2}:{_seconds.Ticks:D2} {suffix}";
            }
            else
            {
                return $"{hr:D2}:{_minutes.Ticks:D2}:{_seconds.Ticks:D2}";
            }
        }
    }
}

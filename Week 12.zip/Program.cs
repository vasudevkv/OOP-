using System;
using System.Diagnostics;

namespace CounterTask
{
    class Program
    {
        static void Main(string[] args)
        {
            int lastStudentIdDigit = 9;

            bool is12HourFormat = lastStudentIdDigit <= 5;
            Clock clock = new Clock(is12HourFormat);

            Console.WriteLine("Clock Format: " + (is12HourFormat ? "12-hour" : "24-hour"));
            Console.WriteLine("Current Time: " + clock.GetTime());

            Stopwatch sw = Stopwatch.StartNew();
            for (int i = 0; i < 100; i++)
            {
                clock.Tick();
            }


            clock.Tick();

            sw.Stop();

            Console.WriteLine("After Tick: " + clock.GetTime());
            Console.WriteLine("Execution Time: {0} ms", sw.ElapsedMilliseconds);

            Process proc = Process.GetCurrentProcess();
            Console.WriteLine("Memory Used: {0} bytes", proc.WorkingSet64);

            clock.Reset();
            Console.WriteLine("After Reset: " + clock.GetTime());
        }
    }
}

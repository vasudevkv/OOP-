using System;
using SwinAdventure;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Enter player name: ");
        var name = Console.ReadLine();
        Console.Write("Enter player description: ");
        var desc = Console.ReadLine();
        var player = new Player(name, desc);

       
        player.Inventory.Put(new Item(new[] { "silver" }, "Silver Hat", "A shiny silver hat"));
        player.Inventory.Put(new Item(new[] { "light"  }, "Torch",      "A wooden torch"));

        
        var bag = new Bag(new[] { "backpack" }, "Leather Backpack", "A durable leather backpack");
        bag.Inventory.Put(new Item(new[] { "map" }, "Treasure Map", "An old treasure map"));
        player.Inventory.Put(bag);

        var look = new LookCommand(new[] { "look" });
        Console.WriteLine("\nType commands like \"look at torch\" or \"look at map in backpack\".");
        Console.WriteLine("Type \"quit\" to exit.\n");

        while (true)
        {
            Console.Write("> ");
            var input = Console.ReadLine()?.Trim();
            if (string.IsNullOrEmpty(input) || input.ToLower() == "quit")
                break;

            var parts = input.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            Console.WriteLine(look.Execute(player, parts) + "\n");
        }
    }
}

using System;

namespace SwinAdventure
{
    public class LookCommand : Command
    {
        public LookCommand(string[] ids) : base(ids) { }

        public override string Execute(Player p, string[] text)
        {
           
            if (text.Length != 3 && text.Length != 5)
                return "I don't know how to look like that";

            if (text[0].ToLower() != "look")
                return "Error in look input";

            if (text[1].ToLower() != "at")
                return "What do you want to look at?";

            IHaveInventory container;
            if (text.Length == 3)
            {
                container = p;  
            }
            else
            {
                if (text[3].ToLower() != "in")
                    return "What do you want to look in?";

                var obj = p.Locate(text[4].ToLower());
                container = obj as IHaveInventory;
                if (container == null)
                    return $"I cannot find the {text[4]}";
            }

            return LookAtIn(text[2].ToLower(), container);
        }

        private string LookAtIn(string thingId, IHaveInventory container)
        {
            var obj = container.Locate(thingId);
            if (obj == null)
                return $"I cannot find the {thingId} in the {container.Name}";
            return obj.FullDescription; 
        }

         [Test]
        public void TestLookInvalidInputLength()
        {
            var output = _command.Execute(_player, new[] { "look", "around", "quickly", "now" });
            Assert.AreEqual("I don't know how to look like that", output);
        }

    }
}
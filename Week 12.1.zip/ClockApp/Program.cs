﻿using System;
using System.Diagnostics;

namespace ClockApp
{
    public class Program
    {
        private static void Main(string[] args)
        {
            // start timing
            var stopwatch = Stopwatch.StartNew();

            var MyClock = new Clock();
            for (int i = 0; i < 10000; i++)
            {
                MyClock.Tick();
            }

            stopwatch.Stop();
            Console.WriteLine($"Time elapsed: {stopwatch.Elapsed}");

            // show clock value after 10 000 ticks
            Console.WriteLine(MyClock.GetTime());

            // reset and show 00:00:00
            MyClock.Restart();
            Console.WriteLine(MyClock.GetTime());

            // show current process memory usage
            var proc = Process.GetCurrentProcess();
            Console.WriteLine($"Memory usage: {proc.WorkingSet64:N0} bytes");
        }
    }
}

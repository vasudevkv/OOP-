using NUnit.Framework;
using SwinAdventure;

namespace SwinAdventure.Tests
{
    [TestFixture]
    public class IdentifiableObjectTests
    {
        private IdentifiableObject _testObject;

        [SetUp]
        public void Setup()
        {
            
            _testObject = new IdentifiableObject(new string[] { "s104672319", "vasudev", "luffy" });
        }

        
        [Test]
        public void TestAreYou()
        {
            Assert.IsTrue(_testObject.AreYou("s104672319"));
            Assert.IsTrue(_testObject.AreYou("VASUDEV")); 
        }

        
        [Test]
        public void TestNotAreYou()
        {
            Assert.IsFalse(_testObject.AreYou("sO04672319")); 
            Assert.IsFalse(_testObject.AreYou("brook"));
        }

        
        [Test]
        public void TestCaseInsensitive()
        {
            Assert.IsTrue(_testObject.AreYou("LUFFY"));
            Assert.IsTrue(_testObject.AreYou("LuFfy"));
        }

        
        [Test]
        public void TestFirstId()
        {
            Assert.AreEqual("s104672319", _testObject.FirstId);
        }

        
        [Test]
        public void TestFirstIdWithNoIds()
        {
            IdentifiableObject emptyObj = new IdentifiableObject(new string[] { });
            Assert.AreEqual("", emptyObj.FirstId);
        }

        
        [Test]
        public void TestAddIdentifier()
        {
            _testObject.AddIdentifier("vasudev");
            Assert.IsTrue(_testObject.AreYou("VASUDEV"));
        }

        
        [Test]
        public void TestPrivilegeEscalation()
        {
            
            _testObject.PrivilegeEscalation("2319");
            Assert.AreEqual("COS20031", _testObject.FirstId); 

            
            IdentifiableObject obj2 = new IdentifiableObject(new string[] { "wrong" });
            obj2.PrivilegeEscalation("5870");
            Assert.AreEqual("wrong", obj2.FirstId);
        }
    }
}
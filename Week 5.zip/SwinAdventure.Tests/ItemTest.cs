using NUnit.Framework;
using SwinAdventure;

namespace SwinAdventure.Tests
{
    [TestFixture]
    public class ItemTests
    {
        private Item _testItem;

        [SetUp]
        public void Setup()
        {
            _testItem = new Item(
                new string[] { "sword", "bronze" },
                "bronze sword",
                "A shiny medieval weapon"
            );
        }

        
        [Test]
        public void TestIsIdentifiable()
        {
            Assert.IsTrue(_testItem.AreYou("sword"));
            Assert.IsTrue(_testItem.AreYou("BRONZE")); 
        }

        
        [Test]
        public void TestShortDescription()
        {
            Assert.AreEqual("a bronze sword (sword)", _testItem.ShortDescription);
        }

        
        [Test]
        public void TestFullDescription()
        {
            Assert.AreEqual("A shiny medieval weapon", _testItem.FullDescription);
        }

        
        [Test]
        public void TestItemPrivilegeEscalation()
        {
            _testItem.PrivilegeEscalation("2319"); 
            Assert.AreEqual("COS20031", _testItem.FirstId); 
        }
    }
}
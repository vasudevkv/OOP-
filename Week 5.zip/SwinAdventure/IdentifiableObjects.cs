﻿using System.Collections.Generic;

namespace SwinAdventure
{
    public class IdentifiableObject
    {
        private List<string> _identifiers = new List<string>();

        public IdentifiableObject(string[] idents)
        {
            foreach (string id in idents)
            {
                AddIdentifier(id);
            }
        }

        public bool AreYou(string id)
        {
            return _identifiers.Contains(id.ToLower());
        }

        
        public string FirstId
        {
            get { return _identifiers.Count > 0 ? _identifiers[0] : ""; }
        }

        
        public void AddIdentifier(string id)
        {
            _identifiers.Add(id.ToLower());
        }

        
        public void RemoveIdentifier(string id)
        {
            string lowerId = id.ToLower();
             _identifiers.Remove(id.ToLower());

        }

        
        public void PrivilegeEscalation(string pin)
        {
            string lastFourDigits = "2319"; 
            if (pin == lastFourDigits && _identifiers.Count > 0)
            {
                _identifiers[0] = "COS20031"; 
            }
        }
    }
}